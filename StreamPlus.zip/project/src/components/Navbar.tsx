import { Bell, Search, User } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  window.onscroll = () => {
    setIsScrolled(window.scrollY > 0);
    return () => (window.onscroll = null);
  };

  return (
    <nav className={`fixed w-full z-50 transition-colors duration-300 ${
      isScrolled ? 'bg-zinc-900/90' : ''
    }`}>
      <div className="px-4 md:px-16 py-6 flex items-center">
        <Link to="/" className="text-red-600 text-2xl font-bold">STREAMPLUS</Link>
        
        <div className="flex-1 ml-8 gap-7 hidden lg:flex">
          <Link to="/" className="text-white hover:text-gray-300 transition">Home</Link>
          <Link to="/series" className="text-white hover:text-gray-300 transition">Series</Link>
          <Link to="/movies" className="text-white hover:text-gray-300 transition">Movies</Link>
          <Link to="/new" className="text-white hover:text-gray-300 transition">New & Popular</Link>
          <Link to="/mylist" className="text-white hover:text-gray-300 transition">My List</Link>
        </div>

        <div className="flex items-center gap-7 ml-auto">
          <div className="text-gray-200 hover:text-gray-300 cursor-pointer">
            <Search className="w-6" />
          </div>
          <div className="text-gray-200 hover:text-gray-300 cursor-pointer">
            <Bell className="w-6" />
          </div>
          <div className="text-gray-200 hover:text-gray-300 cursor-pointer">
            <User className="w-6" />
          </div>
        </div>
      </div>
    </nav>
  );
}