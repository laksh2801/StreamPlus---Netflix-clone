import { Play, Plus, ThumbsUp } from 'lucide-react';
import { useState } from 'react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
}

export default function MovieCard({ movie }: MovieCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="group bg-zinc-900 relative h-[12vw] w-[24vw] md:w-[16vw]"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <img 
        className={`
          cursor-pointer
          object-cover
          transition
          duration-300
          shadow-xl
          rounded-md
          w-full
          h-[12vw]
          ${isHovered ? 'opacity-0' : 'opacity-100'}
        `}
        src={movie.thumbnailUrl} 
        alt={movie.title}
      />
      
      {isHovered && (
        <div className="
          absolute
          top-0
          z-10
          w-full
          scale-110
          opacity-100
          shadow-xl
          rounded-md
          bg-zinc-800
          transition
          duration-300
        ">
          <img 
            className="
              cursor-pointer
              object-cover
              transition
              duration-300
              shadow-xl
              rounded-t-md
              w-full
              h-[12vw]
            "
            src={movie.thumbnailUrl} 
            alt={movie.title}
          />
          
          <div className="p-2 lg:p-4">
            <div className="flex flex-row items-center gap-3">
              <button className="
                cursor-pointer 
                w-6 h-6 lg:w-10 lg:h-10 
                bg-white 
                rounded-full 
                flex 
                justify-center 
                items-center 
                hover:bg-neutral-300
                transition
              ">
                <Play className="w-4 lg:w-6" fill="black"/>
              </button>
              <button className="
                cursor-pointer 
                w-6 h-6 lg:w-10 lg:h-10 
                border-2
                border-white
                rounded-full 
                flex 
                justify-center 
                items-center
                hover:border-neutral-300
                transition
              ">
                <Plus className="w-4 lg:w-6 text-white" />
              </button>
              <button className="
                cursor-pointer 
                w-6 h-6 lg:w-10 lg:h-10 
                border-2
                border-white
                rounded-full 
                flex 
                justify-center 
                items-center
                hover:border-neutral-300
                transition
              ">
                <ThumbsUp className="w-4 lg:w-6 text-white" />
              </button>
            </div>
            
            <div className="flex flex-row mt-4 gap-2 items-center">
              <p className="text-white text-[10px] lg:text-sm">{movie.duration}</p>
              <p className="text-white text-[10px] lg:text-sm">{movie.genre}</p>
              <p className="text-white text-[10px] lg:text-sm">{movie.year}</p>
            </div>
            
            <p className="text-white text-[10px] lg:text-sm mt-4 line-clamp-3">
              {movie.description}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}