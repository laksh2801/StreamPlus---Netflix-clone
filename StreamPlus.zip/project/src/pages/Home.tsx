import Billboard from '../components/Billboard';
import MovieList from '../components/MovieList';
import Navbar from '../components/Navbar';
import { movies } from '../data/movies';

export default function Home() {
  return (
    <div className="relative h-screen bg-gradient-to-b from-gray-900/10 to-[#010511] lg:h-[140vh]">
      <Navbar />
      <Billboard />
      <div className="relative pb-24 space-y-8 md:space-y-16">
        <MovieList title="Trending Now" movies={movies} />
        <MovieList title="Popular on StreamPlus" movies={movies} />
        <MovieList title="New Releases" movies={movies} />
        <MovieList title="Watch Again" movies={movies} />
      </div>
    </div>
  );
}