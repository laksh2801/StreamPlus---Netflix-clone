export interface Movie {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  genre: string;
  duration: string;
  year: number;
}

export interface Profile {
  id: number;
  name: string;
  imageUrl: string;
}

export interface User {
  email: string;
  profiles: Profile[];
}