export const movies = [
  {
    id: 1,
    title: "The Mountain's Echo",
    description: "A thrilling adventure through untamed wilderness.",
    thumbnailUrl: "https://images.unsplash.com/photo-1682686580391-615b1e32be1d",
    genre: "Adventure",
    duration: "2h 15m",
    year: 2024,
  },
  {
    id: 2,
    title: "Digital Dreams",
    description: "A mind-bending journey into virtual reality.",
    thumbnailUrl: "https://images.unsplash.com/photo-1682686580186-b55d2a91053c",
    genre: "Sci-Fi",
    duration: "1h 58m",
    year: 2024,
  },
  {
    id: 3,
    title: "Urban Legends",
    description: "Mystery unfolds in the heart of the city.",
    thumbnailUrl: "https://images.unsplash.com/photo-1682687982501-1e58ab814714",
    genre: "Mystery",
    duration: "2h 5m",
    year: 2024,
  },
] as const;